//Button 1 Rectangle
var x1 = 80;
var y1 = 330;
var w1 = 75;
var h1 = 45;
//Button 2 Ellipse
var x2 = 200;
var y2 = 352.5;
var w2 = 30;
var h2 = 30;
var radius = 30;
//Button 3 Rectangle
var x3 = 245;
var y3 = 330;
var w3 = 75;
var h3 = 45;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255,1);
  background(255, 255, 255, 1);
  ellipseMode(RADIUS);
}

function draw() {
  //screen
  strokeWeight(5);
  stroke(0, 0, 0, 1);
  fill(70, 70, 70);
  beginShape();
  vertex(1,1);
  vertex(399, 1);
  vertex(399, 399);
  vertex(1, 399);
  beginContour();
  vertex(40, 40);
  vertex(40, 310);
  vertex(360, 310);
  vertex(360, 40);
  endContour();
  endShape(CLOSE);
  
  //rectangle button
  strokeWeight(2);
  stroke(0, 0, 0)
  fill(200, 200,200);
  rect(x1, y1, w1, h1);
  
  //ellipse button
  strokeWeight(2);
  stroke(0, 0, 0);
  fill(200, 200, 200);
  ellipse(x2, y2, w2, h2);
  
  //3rd button - rectangle
  strokeWeight(2);
  stroke(0, 0, 0);
  fill(200, 200, 200);
  rect(x3, y3, w3, h3);
  
  //button 3
  if (keyIsPressed) {
    if (key === 'o') {
      if ((mouseX > x3) && (mouseX < x3+w3) && (mouseY > y3) && (mouseY < y3+h3)){
          strokeWeight(5);
          fill(125);
          rect(40, 40, 320, 270);
    } else {
      strokeWeight(5);
      fill(255);
      rect(40, 40, 320, 270);
      }
  }  
 }
}
//button 1
function mouseClicked() {
  if ((mouseX > x1) && (mouseX < x1+w1) && (mouseY > y1) && (mouseY < y1+h1)){
    strokeWeight(0);
    fill(21, 137, 237);
    rect(40, 40, 320, 54);
    fill(36, 209, 83);
    rect(40, 94, 320, 54);
    fill(230, 222, 41);
    rect(40, 148, 320, 54);
    fill(214, 111, 15);
    rect(40, 202, 320, 54);
    fill(245, 2, 125);
    rect(40, 256, 320, 54);
  } else {
//button 2
  var d = dist(mouseX, mouseY, x2, y2);
  if (d < radius){
    strokeWeight(0);
    fill(0);
    ellipse (200, 175, 50, 50);
  } else {
    strokeWeight(0);
    fill(255);
    rect(40, 40, 320, 54);
    rect(40, 94, 320, 54);
    rect(40, 148, 320, 54);
    rect(40, 202, 320, 54);
    rect(40, 256, 320, 54);
    }
  }
}