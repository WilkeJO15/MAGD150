var img1;
var img2;

function preload() {
  
  img1 = loadImage("questionmark.jpg");
  
  img2 = loadImage("rickroll.gif");
}

function setup() {
  createCanvas(1000, 400);
}

function draw() {
  background(220);
  
  stroke(0);
  strokeWeight(3);
  fill(255);
  textFont('fantasy');
  textSize(32);
  text('What could this be?', 10, 300, 250, 100)
  
    image(img2, mouseX, mouseY, 0, 0);

  image(img1, 0, 0, mouseX * 1.5, mouseY * 1.5);
}