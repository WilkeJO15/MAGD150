var z = [5, 10];
var num = 60;
var x = [];
var y = [];

function setup() {
  createCanvas(400, 400);
  for (var i = 0; i < 3000; i++) {
   z[i] = random(-1000, 200);
  }
  print(z.length);
      
}
function draw() {
  background(0);
  let mx = mouseX;
  let my = mouseY;
  
  for (var i = 0; i < z.length; i++){
    z[i] += 0.5;
    var a= i * 1;
    fill(255, 255, 255);
    rect(a, z[i], 10, 10);
  }
  
  //mouse tracking
  noStroke();
  for (var i = num-1; i > 0; i--) {

		x[i] = x[i-1];

		y[i] = y[i-1];
	}

	x[0] = mouseX;

	y[0] = mouseY; 

	for (var i = 0; i < num; i++) {

		fill(255, i *4, 0);
      
		rect(x[i], y[i], 40, 40);
	}
  
  
}